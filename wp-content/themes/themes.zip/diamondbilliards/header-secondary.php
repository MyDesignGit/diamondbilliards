<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Diamond Billiards</title>
		<?php wp_head(); ?>
		
	</head>
	<body>

			<header>
			<div class="container-fluid">
			<?php 
			wp_nav_menu(

				array(
					'theme_location' => 'top-menu'
				)
			);
			?>
			</div>
		</header>
	
	
<?php get_header();?>


<section class="page-wrap">
<div class="container">
	
Blog page
	<?php get_template_part('includes/section','archive');?>



</div>

<section class="page-wrap">


<?php get_footer();?>